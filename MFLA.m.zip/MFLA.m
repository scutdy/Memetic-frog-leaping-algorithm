function  MFLA 
    
for para= 1.2       
       for parap2=5  
           num=1;
      
          m=parap2; 
          n=round(20/m);
          le=n;
          q=m*n;
           beta=para;
          M=30;
          MAX_FES=M*1e4;

for problemIndex =1
     
        onebest=zeros(1,num);% 
        allbest=zeros(num,MAX_FES);% ÓÅ½â
        
      switch problemIndex

        case 1% 
            % 1.This is sphere function
                       Dmin= -100;
                       Dmax =100;
                        func_num=1;%ÆÀ¹Àº¯Êý
                       bestvalue=-1400;
          
   end


   
 for tdy=1:num
       
  FES=0;
  tic; t1=clock; 
  rand('seed', sum(100*clock));   
  frog=struct('fitness',{},'center',{});
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
for i=1:q   
data=Dmin+(Dmax-Dmin).*rand(1,M);    
fitness=cec14_func(data',func_num);
frog(i).fitness=fitness;
frog(i).center=data;
FES=FES+1;
 if i==1
       tempFrog=frog(1);
               
   end
           
           if frog(i).fitness< tempFrog.fitness
               tempFrog=frog(i);
             
           end
              allbest(tdy,FES)= tempFrog.fitness;
               
              fprintf('MFLA(%d) =%g\n',FES,allbest(tdy,FES));

end
 

%%%%%%%%%%%%%%%%%
 
while FES<=MAX_FES%»ìºÏÅÅÐò
        if  FES>MAX_FES
                break;
        end
  
for i=1:q-1
    for j=1:q-i
        if frog(j).fitness < frog(j+1).fitness
            temp=frog(j+1).fitness;
            temp2=frog(j+1).center;
            
             frog(j+1).fitness=frog(j).fitness;
             frog(j+1).center=frog(j).center;
             
             frog(j).center=temp2;
             frog(j).fitness=temp;
        end 
    end
end
  
  for ttt=1:m
        memory(ttt).center =zeros(size( frog(1).center,1),size( frog(1).center,2));
  end 
 
for k=1:le  
      
for i=1:m
    
     %%%%%%%%%%%%%
    Xw= frog(i);
     XwNo=i;
      locXwNO=1;
      
     Xb= frog(i);
     XbNo=i;
     locXbNO=1;
     
     Xwb=frog(i);
      locMean=[];
      fitMeans=zeros(1,n);
               
            for tt=1:n
                  if  frog(i+m*(tt-1)).fitness<Xb.fitness
                      Xb=frog(i+m*(tt-1));
                       XbNo=i+m*(tt-1) ;
                      locXbNO=tt ;
                  end
                  if  frog(i+m*(tt-1)).fitness>Xw.fitness
                      Xw=frog(i+m*(tt-1));
                     XwNo=i+m*(tt-1) ;
                     locXwNO=tt;
                  end
                fitMeans(tt)=frog(i+m*(tt-1)).fitness;  
                 locMean=[locMean;
                               frog(i+m*(tt-1)).center];
            end
            
            w11=rand ;
             v11=rand ;
             Xwb.center=(w11/(w11+v11)).*Xb.center+(v11/(w11+v11)).*Xw.center;       
           
             for tt2=1:n     
                 dis(tt2)= norm(frog((i+m*(tt2-1))).center-frog(XbNo).center,2)^2 +eps;  
             end         
              
              %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%               temploc=locXbNO;
              temploc=locXwNO;
 
             [Mass]=massCalculation(fitMeans,1);
             
              tempDis= dis;
              tempDis([ temploc  ])=[];
              
              tempMass= Mass;
              tempMass([ temploc  ])=[];
                
              Gm= tempMass./tempDis;
              totalGm=sum(Gm);
              Gm=Gm./totalGm;
         
               tempLocalMeans= locMean;
               tempLocalMeans([ temploc  ],:)=[];
               
              mbest1=  sum(tempLocalMeans,1)/n ;
              mbest2=  sum(Gm'*ones(1,M).*tempLocalMeans,1) ;
                 
               sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
               u=randn(size(frog(1).center))*sigma;
              vw=randn(size(frog(1).center));
               step=u./abs(vw).^(1/beta)   ;
              stepsize=  rand  .*(randn) .*step; %levy ·ÉÐÐ²½³¤
               
              
                if rand<0.5 
                   mbest=  mbest1;
          
                else
                    mbest= mbest2;
                    
                end
                
                  temp=Xw.center;
              
                 temp= Xwb.center+rand* (stepsize.*mbest -frog((XwNo)).center)  ;
 
                temp(temp>Dmax)=Dmax;
                temp(temp<Dmin)=Dmin;
                           
                             
                 fitness =cec14_func(temp',func_num);
                 FES=FES+1;
                             
                  if  fitness <frog((XwNo)).fitness
                                 frog((XwNo)).center  = temp ;
                                 frog((XwNo)).fitness=fitness;
                 end
             % 
                   if  fitness< tempFrog.fitness    
                             tempFrog.center=temp;
                             tempFrog.fitness=fitness;
                   end                               
                 if  FES>MAX_FES
                            break;
                 end
                 allbest(tdy,FES)= tempFrog.fitness;
                              
                if mod(FES,2113)==0
                               fprintf('MFLA(%d) =%g\n',FES,allbest(tdy,FES));
                end
                  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      
    end%m
 
end%le
%%
   %%
  for iii=1:q         
          frogA(iii,:)=frog(iii).center;    
      end
     map=zeros(q,M); % see Algorithm-2 in [1]         
  
  for i=1:q 
       u=randperm(M); 
       map(i,u(1:ceil(rand*M)))=1;
  end
      
   K=rand(size(frogA))>0 ;
   stepsize=  rand.*map.*  (frogA(randperm(q),:)-frogA(randperm(q),:));
  
  new_frogA=frogA+stepsize.* K;
  
      for jjj=1:q
           data=new_frogA(jjj,:);
           data(data>Dmax)=Dmax;
           data(data<Dmin)=Dmin;
           fitness=cec14_func(data',func_num);
            
           if fitness<frog(jjj).fitness
               frog(jjj).center=data;
               frog(jjj).fitness=fitness;   
           end  
             FES= FES+1;
             %¼ÇÂ¼Ã¿¸öFES×î¼ÑÊÊÓ¦¶ÈÖµ
                           
          if  fitness< tempFrog.fitness    
                  tempFrog.center=data;
                 tempFrog.fitness=fitness;
          end
                           
           if  FES>MAX_FES
                            break;
              end
              allbest(tdy,FES)= tempFrog.fitness;
                                %³É¹¦ÂÊ
                              
                if mod(FES,2113)==0
                               fprintf('MFLA(%d) =%g\n',FES,allbest(tdy,FES));
               end
                             
                 % 
            
      end
%          
%        



end%while
  
 toc;etime(clock,t1) ;
  onebest(tdy)=allbest (tdy,MAX_FES);

 end%tdy
 
 
        end%21function
        
      end%parap2
      
end% para





% sbest(tdy)
function [M]=massCalculation(fit,min_flag)
%%%%here, make your own function of 'mass calculation'

Fmax=max(fit); Fmin=min(fit); Fmean=mean(fit); 
[i N]=size(fit);

if Fmax==Fmin
   M=ones(1,N);
else
    
   if min_flag==1 %for minimization
      best=Fmin;worst=Fmax; %eq.17-18.
   else %for maximization
      best=Fmax;worst=Fmin; %eq.19-20.
   end
  
   M=1*(fit-worst)./(best-worst)+0  ; %eq.15,

end

M=M./sum(M); %eq. 16.

 
 